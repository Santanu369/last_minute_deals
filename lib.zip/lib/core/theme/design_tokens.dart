import 'package:flutter/material.dart';

/// Last Minutes Deal – Design System tokens (from the design-system PDF).
/// Sizes here are the raw design values; apply .w/.h/.r/.sp at the call site.
class DS {
  DS._();

  // ---------------- Font ----------------
  static const String fontFamily = 'Inter';

  // ---------------- Colors ----------------
  static const Color background = Color(0xFFF5F6FA);
  static const Color card = Color(0xFFFFFFFF);
  static const Color borderLight = Color(0xFFEFEFF2);
  static const Color borderMedium = Color(0xFFE5E7EB);
  static const Color textPrimary = Color(0xFF111827);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textTertiary = Color(0xFF9CA3AF);
  static const Color primaryBlue = Color(0xFF3B5BFF);
  static const Color primaryDark = Color(0xFF2F4EFF);
  static const Color accentRed = Color(0xFFFF2D55);
  static const Color success = Color(0xFF10B981);
  static const Color successLight = Color(0xFFE6F6ED);
  static const Color starYellow = Color(0xFFFFB800);

  // ---------------- Radius ----------------
  static const double radiusCard = 20;
  static const double radiusInput = 12;
  static const double radiusButton = 16;
  static const double radiusPill = 999;
  static const double radiusHero = 24;

  // ---------------- Layout ----------------
  static const double maxWidth = 420;
  static const double screenPadding = 16;

  // ---------------- Shadows ----------------
  // 0 4px 20px rgba(0,0,0,0.06)
  static const List<BoxShadow> shadowCard = [
    BoxShadow(color: Color(0x0F000000), offset: Offset(0, 4), blurRadius: 20),
  ];

  // 0 4px 12px rgba(59,91,255,0.3)
  static const List<BoxShadow> shadowButton = [
    BoxShadow(color: Color(0x4D3B5BFF), offset: Offset(0, 4), blurRadius: 12),
  ];
}