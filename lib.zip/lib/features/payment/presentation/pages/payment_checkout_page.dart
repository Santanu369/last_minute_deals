import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cashfree_pg_sdk/api/cferrorresponse/cferrorresponse.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpayment/cfwebcheckoutpayment.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfpaymentgateway/cfpaymentgatewayservice.dart';
import 'package:flutter_cashfree_pg_sdk/api/cfsession/cfsession.dart';
import 'package:flutter_cashfree_pg_sdk/utils/cfenums.dart';
import 'package:intl/intl.dart';
import 'package:lmd_app/app/shell/navbar_widget.dart';
import 'package:lmd_app/features/booking/presentation/pages/booking_success_screen.dart';
// import 'package:lmd_app/pages/bookingPages/widgets/booking_verify_page.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:lmd_app/features/payment/data/services/payment_service_impl.dart';

class PaymentCheckoutPage extends StatefulWidget {
  final double totalAmount;
  final String stayName;
  final String guestEmail;
  final String guestPhone;
  final String? bookingId; // Real booking ID from backend

  const PaymentCheckoutPage({
    super.key,
    required this.totalAmount,
    required this.stayName,
    required this.guestEmail,
    required this.guestPhone,
    this.bookingId,
  });

  @override
  State<PaymentCheckoutPage> createState() => _PaymentCheckoutPageState();
}

// ---- Colors used across the design ----
const Color _kRed = Color(0xffE53935);
const Color _kTextDark = Color(0xff1A1A1A);
const Color _kTextGrey = Color(0xff8A8A8A);
const Color _kBorder = Color(0xffE5E7EB);

enum _PaymentMethod { upi, card, netBanking, wallets, payLater, emi }

class _PaymentCheckoutPageState extends State<PaymentCheckoutPage> {
  bool _isLoading = false;
  String? _orderId;
  String? _paymentSessionId;
  _PaymentMethod _selectedMethod = _PaymentMethod.upi;

  final CFPaymentGatewayService _cfPaymentGatewayService =
      CFPaymentGatewayService();

  bool get _cashfreeSupported =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.android ||
          defaultTargetPlatform == TargetPlatform.iOS);

  @override
  void initState() {
    super.initState();
    if (_cashfreeSupported) {
      _cfPaymentGatewayService.setCallback(verifyPayment, onError);
    }
  }

  void verifyPayment(String orderId) async {
    debugPrint('✅ PAYMENT SUCCESSFUL: $orderId');

    // Sync backend status
    if (widget.bookingId != null) {
      try {
        await PaymentServiceImpl().syncPayment(bookingId: widget.bookingId!);
        await Future.delayed(const Duration(seconds: 2));
      } catch (e) {
        debugPrint('Backend Sync Error: $e');
      }
    }

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => BookingSuccessScreen(
          bookingId: orderId,
          amountPaid: widget.totalAmount,
          paymentId: orderId,
        ),
      ),
      // MaterialPageRoute(
      //   // builder: (context) => PaymentSuccessPage(
      //   //   bookingId: widget.bookingId ?? orderId,
      //   //   hotelId: '',
      //   //   hotelName: widget.stayName,
      //   //   checkIn: '',
      //   //   checkOut: '',
      //   //   status: 'COMPLETED',
      //   //   createdAt: DateTime.now().toIso8601String(),
      //   //   image: '',
      //   //   city: '',
      //   //   countryCode: '',
      //   //   address: '',
      //   //   description: '',
      //   // ),
      // ),
    );
  }

  void onError(CFErrorResponse error, String orderId) {
    debugPrint('❌ PAYMENT ERROR: ${error.getMessage()}');
    setState(() => _isLoading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Payment Failed: ${error.getMessage()}')),
    );
  }

  Future<void> _createOrderAndPay() async {
    if (widget.bookingId == null) return;

    if (!_cashfreeSupported) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cashfree payments are supported on Android and iOS.'),
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await PaymentServiceImpl().createCashfreeOrder(
        bookingId: widget.bookingId!,
        idempotencyKey: DateTime.now().millisecondsSinceEpoch.toString(),
      );

      setState(() {
        _orderId = response.orderId;
        _paymentSessionId = response.paymentSessionId;
      });

      _openCashfree();
    } catch (e) {
      debugPrint('🔥 Backend Order Error: $e');
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Unable to start payment: $e')));
      }
    }
  }

  void _openCashfree() async {
    if (!_cashfreeSupported || _orderId == null || _paymentSessionId == null) {
      return;
    }
    try {
      final session = CFSessionBuilder()
          .setOrderId(_orderId!)
          .setPaymentSessionId(_paymentSessionId!)
          .setEnvironment(
            dotenv.get('CASHFREE_ENV', fallback: 'TEST') == 'PRODUCTION'
                ? CFEnvironment.PRODUCTION
                : CFEnvironment.SANDBOX,
          )
          .build();

      final payment = CFWebCheckoutPaymentBuilder().setSession(session).build();
      setState(() => _isLoading = false);
      _cfPaymentGatewayService.doPayment(payment);
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat('#,##,##0', 'en_IN');

    return Theme(
      data: Theme.of(context).copyWith(
        textTheme: Theme.of(context).textTheme.apply(fontFamily: 'Inter'),
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        bottomNavigationBar: const NavbarWidget(),
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, size: 18, color: _kTextDark),
            onPressed: () => Navigator.pop(context),
          ),
          title: const Text(''),
          centerTitle: true,
          backgroundColor: Colors.white,
          elevation: 0,
        ),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 4,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Select Payment Method',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: _kTextDark,
                          fontFamily: 'Inter',
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Choose a payment option to continue.',
                        style: TextStyle(
                          fontSize: 13.5,
                          color: _kTextGrey,
                          fontFamily: 'Inter',
                        ),
                      ),
                      const SizedBox(height: 22),
                      _sectionLabel('Recommended'),
                      const SizedBox(height: 10),
                      _methodTile(
                        method: _PaymentMethod.upi,
                        icon: Icons.radio_button_checked,
                        iconBg: const Color(0xffFFF1EE),
                        iconColor: _kRed,
                        title: 'UPI',
                        subtitle: 'Pay using any UPI app',
                        trailingBadge: '🇮🇳',
                      ),
                      const SizedBox(height: 22),
                      _sectionLabel('All Payment Options'),
                      const SizedBox(height: 10),
                      _methodTile(
                        method: _PaymentMethod.card,
                        icon: Icons.credit_card_rounded,
                        iconBg: const Color(0xffEFF2FF),
                        iconColor: const Color(0xff1A1A1A),
                        title: 'Credit / Debit Card',
                        subtitle: 'Visa, Mastercard, RuPay',
                      ),
                      _methodTile(
                        method: _PaymentMethod.netBanking,
                        icon: Icons.account_balance_rounded,
                        iconBg: const Color(0xffEAF1FE),
                        iconColor: const Color(0xff2D6CDF),
                        title: 'Net Banking',
                        subtitle: 'All major banks supported',
                      ),
                      _methodTile(
                        method: _PaymentMethod.wallets,
                        icon: Icons.account_balance_wallet_rounded,
                        iconBg: const Color(0xffEAF1FE),
                        iconColor: const Color(0xff2D6CDF),
                        title: 'Wallets',
                        subtitle: 'Paytm, PhonePe, Amazon Pay',
                      ),
                      _methodTile(
                        method: _PaymentMethod.payLater,
                        icon: Icons.fast_forward_rounded,
                        iconBg: const Color(0xffFFF1EE),
                        iconColor: _kRed,
                        title: 'Pay Later',
                        subtitle: 'LazyPay, Simpl, ICICI PayLater',
                      ),
                      _methodTile(
                        method: _PaymentMethod.emi,
                        icon: Icons.calendar_month_rounded,
                        iconBg: const Color(0xffEAF1FE),
                        iconColor: const Color(0xff2D6CDF),
                        title: 'EMI',
                        subtitle: 'Easy EMI options available',
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(22, 12, 22, 22),
                decoration: const BoxDecoration(color: Colors.white),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // ---- Total Amount Box ----
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _kBorder, width: 1),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Total Amount',
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              color: _kTextDark,
                              fontFamily: 'Inter',
                            ),
                          ),
                          Text(
                            '₹${formatter.format(widget.totalAmount)}',
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              color: _kRed,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    // ---- Pay Securely Button ----
                    SizedBox(
                      width: double.infinity,
                      height: 66,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _createOrderAndPay,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kRed,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2.5,
                                ),
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text(
                                    'Pay Securely',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    '₹${formatter.format(widget.totalAmount)}',
                                    style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w800,
                                      color: Colors.white,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w700,
        color: _kTextDark,
        fontFamily: 'Inter',
      ),
    );
  }

  Widget _methodTile({
    required _PaymentMethod method,
    required IconData icon,
    required Color iconBg,
    required Color iconColor,
    required String title,
    required String subtitle,
    String? trailingBadge,
  }) {
    final bool isSelected = _selectedMethod == method;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => setState(() => _selectedMethod = method),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0xffFFF6F5) : Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isSelected ? _kRed : _kBorder,
              width: isSelected ? 1.4 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: iconBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: iconColor, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: _kTextDark,
                        fontFamily: 'Inter',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 12,
                        color: _kTextGrey,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ],
                ),
              ),
              if (trailingBadge != null) ...[
                Text(
                  trailingBadge,
                  style: const TextStyle(fontSize: 18, fontFamily: 'Inter'),
                ),
                const SizedBox(width: 8),
              ],
              Icon(
                isSelected ? Icons.radio_button_checked : Icons.circle_outlined,
                color: isSelected ? _kRed : const Color(0xffC9CCD3),
                size: 24,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
