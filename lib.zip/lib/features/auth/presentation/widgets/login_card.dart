import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lmd_app/core/theme/app_colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lmd_app/features/auth/presentation/cubit/auth_cubit.dart';
import 'package:lmd_app/features/auth/presentation/cubit/auth_state.dart';
import 'package:lmd_app/features/auth/presentation/cubit/auth_status.dart';
import 'package:lmd_app/features/auth/presentation/cubit/forgot_password_cubit.dart';
import 'package:lmd_app/features/auth/presentation/pages/forgot_page.dart';
import 'package:lmd_app/features/auth/presentation/pages/register_page.dart';

class LoginCard extends StatefulWidget {
  const LoginCard({super.key});

  @override
  State<LoginCard> createState() => _LoginCardState();
}

class _LoginCardState extends State<LoginCard> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isVisible = false;
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 500),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: const [
          BoxShadow(
            blurRadius: 16,
            spreadRadius: 0,
            color: Color(0x14000000),
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(height: 8.h),
              // Google button
              InkWell(
                onTap: () async {
                  await context.read<AuthCubit>().googleLogin();
                },
                child: Container(
                  height: 48.h,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8.r),
                    border: Border.all(color: const Color(0xffE5E7EB), width: 1),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/icons/google.png',
                        width: 24.w,
                        height: 24.h,
                      ),
                      SizedBox(width: 12.w),
                      Text(
                        'Sign In With Google',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16.h),
              Row(
                children: [
                  Expanded(
                    child: Divider(thickness: 1, color: Color(0xffE5E7EB)),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12.w),
                    child: Text(
                      'or',
                      style: TextStyle(
                        fontFamily: 'Red Hat Display',
                        fontWeight: FontWeight.w400,
                        fontSize: 16.sp,
                        color: Color(0xff6B7280),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Divider(thickness: 1, color: Color(0xffE5E7EB)),
                  ),
                ],
              ),
              SizedBox(height: 16.h),
              // Email input
              SizedBox(
                height: 76.h,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: TextFormField(
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) {
                      final email = value?.trim() ?? '';

                      if (email.isEmpty) {
                        return 'Email is required';
                      }

                      if (!RegExp(
                        r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                      ).hasMatch(email)) {
                        return 'Enter a valid email';
                      }

                      return null;
                    },
                    controller: emailController,
                    style: TextStyle(fontSize: 14.sp, color: Colors.black, height: 1.4),
                    decoration: InputDecoration(
                      isDense: true,
                      errorStyle: TextStyle(
                        fontSize: 12.sp,
                        height: 1.0,
                      ),
                      hintText: 'Enter your Email',
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                        vertical: 16.5.h,
                      ),
                      hintStyle: TextStyle(
                        color: Color(0xff7F7F7F),
                        fontWeight: FontWeight.w400,
                        fontSize: 14.sp,
                        height: 1.4,
                      ),
                      filled: true,
                      fillColor: const Color(0xffF9FAFB),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: BorderSide(color: AppColors.primary, width: 1.5),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                    ),
                  ),
                ),
              ),
              // Password input
              SizedBox(
                height: 76.h,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: TextFormField(
                    obscureText: !isVisible,
                    controller: passwordController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    validator: (value) {
                      final password = value ?? '';

                      if (password.isEmpty) {
                        return 'Password is required';
                      }

                      return null;
                    },
                    style: TextStyle(fontSize: 14.sp, color: Colors.black, height: 1.4),
                    decoration: InputDecoration(
                      isDense: true,
                      errorStyle: TextStyle(
                        fontSize: 11.sp,
                        height: 1.0,
                      ),
                      hintText: 'Enter Password',
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                        vertical: 16.5.h,
                      ),
                      hintStyle: TextStyle(
                        color: Color(0xff7F7F7F),
                        fontWeight: FontWeight.w400,
                        fontSize: 14.sp,
                        height: 1.4,
                      ),
                      filled: true,
                      fillColor: const Color(0xffF9FAFB),
                      suffixIcon: InkWell(
                        onTap: () {
                          setState(() {
                            isVisible = !isVisible;
                          });
                        },
                        child: Icon(
                          isVisible ? Icons.visibility : Icons.visibility_off,
                          color: const Color(0xff70757A),
                          size: 20.r,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: BorderSide(color: AppColors.primary, width: 1.5),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                    ),
                  ),
                ),
              ),
              // Forgot password link
              Align(
                alignment: Alignment.centerRight,
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BlocProvider(
                          create: (_) => ForgotPasswordCubit(),
                          child: const ForgotPage(),
                        ),
                      ),
                    );
                  },
                  child: Text(
                    'Forgot Password?',
                    style: TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                      fontSize: 14.sp,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 24.h),
              // Login button
              InkWell(
                onTap: () async {
                  if (!_formKey.currentState!.validate()) return;

                  await context.read<AuthCubit>().login(
                    email: emailController.text.trim(),
                    password: passwordController.text.trim(),
                  );
                },
                child: Container(
                  height: 48.h,
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(8.r),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: BlocBuilder<AuthCubit, AuthState>(
                      builder: (context, authState) {
                        return authState.status == AuthStatus.loading
                            ? SizedBox(
                                height: 20.h,
                                width: 20.w,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                'Log In',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14.sp,
                                ),
                              );
                      },
                    ),
                  ),
                ),
              ),
              SizedBox(height: 24.h),
              // Sign up link
              Wrap(
                alignment: WrapAlignment.center,
                children: [
                  Text(
                    "Don't have an account? ",
                    style: TextStyle(
                      fontFamily: 'Red Hat Display',
                      fontWeight: FontWeight.w500,
                      fontSize: 14.sp,
                      color: Color(0xff6B7280),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const RegisterPage()),
                      );
                    },
                    child: Text(
                      'Sign Up',
                      style: TextStyle(
                        fontFamily: 'Red Hat Display',
                        fontWeight: FontWeight.w700,
                        fontSize: 14.sp,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
