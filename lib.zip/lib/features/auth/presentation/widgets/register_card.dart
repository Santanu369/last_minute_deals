import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lmd_app/core/theme/app_colors.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lmd_app/features/auth/presentation/cubit/auth_cubit.dart';
import 'package:lmd_app/features/auth/presentation/cubit/auth_state.dart';
import 'package:lmd_app/features/auth/presentation/cubit/auth_status.dart';
import 'package:lmd_app/features/auth/presentation/pages/login_page.dart';
import 'package:lmd_app/features/auth/presentation/pages/otp_page.dart';
import 'package:lmd_app/features/auth/presentation/cubit/forgot_password_cubit.dart';
import 'package:url_launcher/url_launcher.dart';
// import 'package:lmd_app/providers/auth_provider.dart';
// import 'package:provider/provider.dart';

class RegisterCard extends StatefulWidget {
  const RegisterCard({super.key});

  @override
  State<RegisterCard> createState() => _RegisterCardState();
}

class _RegisterCardState extends State<RegisterCard> {
  final _formKey = GlobalKey<FormState>();
  bool isVisible = false;

  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();

  @override
  void dispose() {
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    phoneController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 500),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: const [
          BoxShadow(
            blurRadius: 16,
            spreadRadius: 0,
            color: Color(0x14000000),
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(height: 8.h),
              // Google button
              InkWell(
                onTap: () async {
                  await context.read<AuthCubit>().googleLogin();
                },
                child: Container(
                  height: 48.h,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8.r),
                    border: Border.all(color: const Color(0xffE5E7EB), width: 1),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/icons/google.png',
                        width: 24.w,
                        height: 24.h,
                      ),
                      SizedBox(width: 12.w),
                      Text(
                        'Sign Up With Google',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16.h),
              Row(
                children: [
                  Expanded(
                    child: Divider(thickness: 1, color: Color(0xffE5E7EB)),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12.w),
                    child: Text(
                      'or',
                      style: TextStyle(
                        fontFamily: 'Red Hat Display',
                        fontWeight: FontWeight.w400,
                        fontSize: 16.sp,
                        color: Color(0xff6B7280),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Divider(thickness: 1, color: Color(0xffE5E7EB)),
                  ),
                ],
              ),
              SizedBox(height: 16.h),
              // First Name & Last Name in Row
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 76.h,
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: TextFormField(
                          controller: firstNameController,
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'First name is required';
                            }
                            if (value.length < 2) {
                              return 'Min 2 chars';
                            }
                            return null;
                          },
                          style: TextStyle(fontSize: 14.sp, color: Colors.black, height: 1.4),
                          decoration: InputDecoration(
                            isDense: true,
                            hintText: 'First Name',
                            contentPadding: EdgeInsets.symmetric(
                              horizontal: 16.w,
                              vertical: 16.5.h,
                            ),
                            hintStyle: TextStyle(
                              color: Color(0xff7F7F7F),
                              fontWeight: FontWeight.w400,
                              fontSize: 14.sp,
                              height: 1.4,
                            ),
                            filled: true,
                            fillColor: const Color(0xffF9FAFB),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.r),
                              borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.r),
                              borderSide: BorderSide(color: AppColors.primary, width: 1.5),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.r),
                              borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: SizedBox(
                      height: 76.h,
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: TextFormField(
                          controller: lastNameController,
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Last name is required';
                            }
                            return null;
                          },
                          style: TextStyle(fontSize: 14.sp, color: Colors.black, height: 1.4),
                          decoration: InputDecoration(
                            isDense: true,
                            hintText: 'Last Name',
                            contentPadding: EdgeInsets.symmetric(
                              horizontal: 16.w,
                              vertical: 16.5.h,
                            ),
                            hintStyle: TextStyle(
                              color: Color(0xff7F7F7F),
                              fontWeight: FontWeight.w400,
                              fontSize: 14.sp,
                              height: 1.4,
                            ),
                            filled: true,
                            fillColor: const Color(0xffF9FAFB),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.r),
                              borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.r),
                              borderSide: BorderSide(color: AppColors.primary, width: 1.5),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.r),
                              borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              // Email input
              SizedBox(
                height: 76.h,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: TextFormField(
                    keyboardType: TextInputType.emailAddress,
                    controller: emailController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Email is required';
                      }
                      if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                        return 'Please enter a valid email address';
                      }
                      return null;
                    },
                    style: TextStyle(fontSize: 14.sp, color: Colors.black, height: 1.4),
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'Enter your Email',
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                        vertical: 16.5.h,
                      ),
                      hintStyle: TextStyle(
                        color: Color(0xff7F7F7F),
                        fontWeight: FontWeight.w400,
                        fontSize: 14.sp,
                        height: 1.4,
                      ),
                      filled: true,
                      fillColor: const Color(0xffF9FAFB),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: BorderSide(color: AppColors.primary, width: 1.5),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                    ),
                  ),
                ),
              ),
              // Phone input
              SizedBox(
                height: 76.h,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: TextFormField(
                    keyboardType: TextInputType.phone,
                    controller: phoneController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Phone number is required';
                      }
                      if (value.trim().length < 8) {
                        return 'Enter a valid phone number';
                      }
                      return null;
                    },
                    style: TextStyle(fontSize: 14.sp, color: Colors.black, height: 1.4),
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'Enter Phone Number',
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                        vertical: 16.5.h,
                      ),
                      hintStyle: TextStyle(
                        color: Color(0xff7F7F7F),
                        fontWeight: FontWeight.w400,
                        fontSize: 14.sp,
                        height: 1.4,
                      ),
                      filled: true,
                      fillColor: const Color(0xffF9FAFB),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: BorderSide(color: AppColors.primary, width: 1.5),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                    ),
                  ),
                ),
              ),
              // Password input
              SizedBox(
                height: 76.h,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: TextFormField(
                    obscureText: !isVisible,
                    controller: passwordController,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Password is required';
                      }
                      if (value.length < 8) {
                        return 'Password must be at least 8 characters';
                      }
                      return null;
                    },
                    style: TextStyle(fontSize: 14.sp, color: Colors.black, height: 1.4),
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'Enter Password',
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                        vertical: 16.5.h,
                      ),
                      hintStyle: TextStyle(
                        color: Color(0xff7F7F7F),
                        fontWeight: FontWeight.w400,
                        fontSize: 14.sp,
                        height: 1.4,
                      ),
                      filled: true,
                      fillColor: const Color(0xffF9FAFB),
                      suffixIcon: InkWell(
                        onTap: () {
                          setState(() {
                            isVisible = !isVisible;
                          });
                        },
                        child: Icon(
                          isVisible ? Icons.visibility : Icons.visibility_off,
                          color: const Color(0xff70757A),
                          size: 20.r,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: BorderSide(color: AppColors.primary, width: 1.5),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.r),
                        borderSide: const BorderSide(color: Color(0xffE5E7EB), width: 1),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 24.h),
              // Sign Up action button
              InkWell(
                onTap: () async {
                  if (!_formKey.currentState!.validate()) return;

                  await context.read<AuthCubit>().signup(
                    email: emailController.text.trim(),
                    password: passwordController.text.trim(),
                    firstName: firstNameController.text.trim(),
                    lastName: lastNameController.text.trim(),
                    phone: phoneController.text.trim(),
                  );

                  if (context.mounted &&
                      context.read<AuthCubit>().state.status == AuthStatus.success) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BlocProvider(
                          create: (_) => ForgotPasswordCubit(),
                          child: OtpPage(
                            userId: context.read<AuthCubit>().state.user?.id,
                            isRegister: true,
                            email: emailController.text.trim(),
                            password: passwordController.text.trim(),
                          ),
                        ),
                      ),
                    );
                  }
                },
                child: Container(
                  height: 48.h,
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(8.r),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: BlocBuilder<AuthCubit, AuthState>(
                      builder: (context, authState) {
                        return authState.status == AuthStatus.loading
                            ? SizedBox(
                                height: 20.h,
                                width: 20.w,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                'Sign Up',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14.sp,
                                ),
                              );
                      },
                    ),
                  ),
                ),
              ),
              SizedBox(height: 16.h),
              // Terms & Conditions statement
              Wrap(
                alignment: WrapAlignment.center,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(
                    'Signing up means you agree to the ',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Red Hat Display',
                      fontSize: 12.sp,
                      color: Color(0xff6B7280),
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      final Uri url = Uri.parse('https://lastminutessdeal.com/privacy');
                      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
                        throw Exception('Could not launch Privacy Policy');
                      }
                    },
                    child: Text(
                      'Privacy Policy',
                      style: TextStyle(
                        fontFamily: 'Red Hat Display',
                        fontWeight: FontWeight.w600,
                        fontSize: 12.sp,
                        color: AppColors.primary,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                  Text(
                    ' and ',
                    style: TextStyle(
                      fontFamily: 'Red Hat Display',
                      fontSize: 12.sp,
                      color: Color(0xff6B7280),
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      final Uri url = Uri.parse('https://lastminutessdeal.com/terms');
                      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
                        throw Exception('Could not launch Terms of Service');
                      }
                    },
                    child: Text(
                      'Terms of Service',
                      style: TextStyle(
                        fontFamily: 'Red Hat Display',
                        fontWeight: FontWeight.w600,
                        fontSize: 12.sp,
                        color: AppColors.primary,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 24.h),
              // Log In redirection link
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Already have an account? ',
                    style: TextStyle(
                      fontFamily: 'Red Hat Display',
                      fontSize: 14.sp,
                      color: Color(0xff6B7280),
                    ),
                  ),
                  InkWell(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                    ),
                    child: Text(
                      'Log In',
                      style: TextStyle(
                        fontFamily: 'Red Hat Display',
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w700,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
