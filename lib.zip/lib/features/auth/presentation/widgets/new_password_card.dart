import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lmd_app/features/auth/presentation/cubit/forgot_password_cubit.dart';

class NewPasswordCard extends StatefulWidget {
  const NewPasswordCard({super.key});

  @override
  State<NewPasswordCard> createState() => _NewPasswordCardState();
}

class _NewPasswordCardState extends State<NewPasswordCard> {
  final _formKey = GlobalKey<FormState>();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.sizeOf(context).height;
    return Container(
      constraints: BoxConstraints(maxWidth: 500),
      height: h * .75,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(40.r),
          topRight: Radius.circular(40.r),
        ),
        boxShadow: [
          BoxShadow(
            blurRadius: 20,
            spreadRadius: 5,
            color: const Color.fromARGB(255, 160, 159, 159),
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(20.0.w),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: .center,
            children: [
              SizedBox(height: 10.h),
              Align(
                alignment: AlignmentGeometry.centerLeft,
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Row(
                    children: [
                      Icon(Icons.arrow_back),
                      SizedBox(width: 5.w),
                      Text(
                        'Back',
                        style: TextStyle(
                          fontFamily: 'Red Hat Display',
                          fontWeight: .w400,
                          fontSize: 16.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10.h),

              Text(
                'New Password',
                style: TextStyle(
                  fontFamily: 'Red Hat Display',
                  fontWeight: .w600,
                  fontSize: 27.sp,
                ),
              ),
              SizedBox(height: 5.h),
              Text(
                'Enter the code &',
                style: TextStyle(
                  fontFamily: 'Red Hat Display',
                  fontWeight: .w400,
                  fontSize: 16.sp,
                ),
              ),
              Text(
                ' write your new password',
                style: TextStyle(
                  fontFamily: 'Red Hat Display',
                  fontWeight: .w400,
                  fontSize: 16.sp,
                ),
              ),

              SizedBox(height: 16.h),

              TextFormField(
                controller: _newPasswordController,
                keyboardType: TextInputType.visiblePassword,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  final newPassword = value?.trim() ?? '';

                  if (newPassword.isEmpty) {
                    return 'newPassword is required';
                  }

                  return null;
                },
                decoration: InputDecoration(
                  hintText: 'New Password',

                  hintStyle: TextStyle(
                    color: Color(0xff7F7F7F),
                    fontWeight: .w400,
                    fontSize: 14.sp,
                  ),

                  filled: true,
                  fillColor: const Color(0xffECECEC),

                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28.r)),

                    borderSide: BorderSide.none,
                  ),
                ),
              ),

              SizedBox(height: 16.h),
              TextFormField(
                controller: _confirmPasswordController,
                // keyboardType: TextInputType.visiblePassword,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  final confirmPassword = value;

                  if (confirmPassword!.isEmpty) {
                    return 'confirmPassword is required';
                  }

                  if (_newPasswordController.text != confirmPassword) {
                    return "confirm password doesn't match";
                  }

                  return null;
                },
                decoration: InputDecoration(
                  hintText: 'Confirm New Password',

                  hintStyle: TextStyle(
                    color: Color(0xff7F7F7F),
                    fontWeight: .w400,
                    fontSize: 14.sp,
                  ),

                  filled: true,
                  fillColor: const Color(0xffECECEC),

                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(28.r)),

                    borderSide: BorderSide.none,
                  ),
                ),
              ),

              SizedBox(height: 20.h),
              InkWell(
                onTap: () {
                  if (!_formKey.currentState!.validate()) {
                    return;
                  }

                  context.read<ForgotPasswordCubit>().resetPassword(
                    newPassword: _newPasswordController.text.trim(),
                    confirmPassword: _confirmPasswordController.text.trim(),
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(28.r),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 5,
                        offset: Offset(3, 4),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(18.w),
                    child: Center(
                      child: Text(
                        'Confirm Password',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
