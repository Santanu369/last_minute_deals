import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lmd_app/features/language/translated_text_wish.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:lmd_app/core/theme/app_colors.dart';
import 'package:lmd_app/core/theme/app_text.dart';
import 'package:lmd_app/core/config/support_config.dart';
import 'package:lmd_app/features/profile/presentation/pages/help_center_page.dart';

class CustomerSupportPage extends StatelessWidget {
  const CustomerSupportPage({super.key});

  Future<void> _launchEmail() async {
    final Uri emailLaunchUri = Uri(
      scheme: 'mailto',
      path: SupportConfig.email,
      queryParameters: {
        'subject': 'Support Request - Last Minutes Deal',
      },
    );
    if (await canLaunchUrl(emailLaunchUri)) {
      await launchUrl(emailLaunchUri);
    }
  }

  Future<void> _launchPhone() async {
    final Uri phoneLaunchUri = Uri(
      scheme: 'tel',
      path: SupportConfig.phone,
    );
    if (await canLaunchUrl(phoneLaunchUri)) {
      await launchUrl(phoneLaunchUri);
    }
  }



  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final screenWidth = mediaQuery.size.width;
    final isSmallScreen = screenWidth < 600;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Back Button Row
              GestureDetector(
                onTap: () => Navigator.pop(context),
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0.h),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.arrow_back,
                        color: AppColors.textSecondary,
                        size: 20.r,
                      ),
                      SizedBox(width: 8.w),
                      TranslatedText(
                        text:'Back to Home',
                        style: AppText.bodyMedium.copyWith(
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 32.h),

              // Red availability badge
              Center(
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.h),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFE4E4),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: TranslatedText(
                    text: SupportConfig.availabilityHeader,
                    style: AppText.bodyMedium.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w700,
                      fontSize: 12.sp,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 16.h),

              // Title "Contact Us"
              Center(
                child: TranslatedText(
                  text: 'Contact Us',
                  style: AppText.h1.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              SizedBox(height: 12.h),

              // Supporting Description
              Center(
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 480),
                  child: TranslatedText(
                    text: 'Have questions about your booking, account, or payment? Reach out anytime and our team will get back to you immediately.',
                    textAlign: TextAlign.center,
                    style: AppText.bodySecondary.copyWith(
                      color: AppColors.textSecondary,
                      fontSize: 14.sp,
                      height: 1.5,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 32.h),

              // Main Help Card
              Center(
                child: Container(
                  width: double.infinity,
                  constraints: const BoxConstraints(maxWidth: 600),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(24.r),
                    border: Border.all(color: AppColors.border),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.03),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  padding: EdgeInsets.all(32.w),
                  child: Column(
                    children: [
                      // Headphone Icon Badge
                      Container(
                        width: 56.w,
                        height: 56.h,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFE4E4),
                          borderRadius: BorderRadius.circular(16.r),
                        ),
                        child: Icon(
                          Icons.headset_mic_outlined,
                          color: AppColors.primary,
                          size: 28.r,
                        ),
                      ),
                      SizedBox(height: 20.h),

                      // "Need Help?" title
                      TranslatedText(
                        text: 'Need Help?',
                        style: AppText.h2.copyWith(
                          color: AppColors.textPrimary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 12.h),

                      // "Our dedicated support..."
                      TranslatedText(
                        text: 'Our dedicated support team is standing by around the clock to assist with your bookings, changes, or any travel inquiries you might have.',
                        textAlign: TextAlign.center,
                        style: AppText.bodySecondary.copyWith(
                          color: AppColors.textSecondary,
                          fontSize: 14.sp,
                          height: 1.5,
                        ),
                      ),
                      SizedBox(height: 32.h),

                      // Contact Options
                      isSmallScreen
                          ? Column(
                              children: [
                                _buildContactOptionCard(
                                  title: 'DIRECT EMAIL',
                                  value: SupportConfig.email,
                                  icon: Icons.mail_outline_rounded,
                                  onTap: _launchEmail,
                                ),
                                SizedBox(height: 16.h),
                                _buildContactOptionCard(
                                  title: '24/7 SUPPORT PHONE',
                                  value: SupportConfig.displayPhone,
                                  icon: Icons.phone_outlined,
                                  onTap: _launchPhone,
                                ),
                              ],
                            )
                          : Row(
                              children: [
                                Expanded(
                                  child: _buildContactOptionCard(
                                    title: 'DIRECT EMAIL',
                                    value: SupportConfig.email,
                                    icon: Icons.mail_outline_rounded,
                                    onTap: _launchEmail,
                                  ),
                                ),
                                SizedBox(width: 16.w),
                                Expanded(
                                  child: _buildContactOptionCard(
                                    title: '24/7 SUPPORT PHONE',
                                    value: SupportConfig.displayPhone,
                                    icon: Icons.phone_outlined,
                                    onTap: _launchPhone,
                                  ),
                                ),
                              ],
                            ),
                      SizedBox(height: 32.h),

                      // Action Buttons
                      isSmallScreen
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                _buildEmailButton(),
                                SizedBox(height: 16.h),
                                _buildHelpCenterButton(context),
                              ],
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(child: _buildEmailButton()),
                                SizedBox(width: 16.w),
                                Expanded(child: _buildHelpCenterButton(context)),
                              ],
                            ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContactOptionCard({
    required String title,
    required String value,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 12.w),
        decoration: BoxDecoration(
          color: const Color(0xFFFAFAFA),
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 10.sp,
                fontWeight: FontWeight.w700,
                color: AppColors.textSecondary,
                letterSpacing: 0.5,
              ),
            ),
            SizedBox(height: 8.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  color: AppColors.primary,
                  size: 16.r,
                ),
                SizedBox(width: 8.w),
                Flexible(
                  child: Text(
                    value,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmailButton() {
    return SizedBox(
      height: 48.h,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.r),
          ),
        ),
        onPressed: _launchEmail,
        child: TranslatedText(
          text: 'Email Us Directly',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: 14.sp,
          ),
        ),
      ),
    );
  }

  Widget _buildHelpCenterButton(BuildContext context) {
    return SizedBox(
      height: 48.h,
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: AppColors.border),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.r),
          ),
          backgroundColor: Colors.white,
          foregroundColor: AppColors.textPrimary,
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const HelpCenterPage(),
            ),
          );
        },
        child: TranslatedText(
          text: 'Visit Help Center',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 14.sp,
          ),
        ),
      ),
    );
  }
}
