import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lmd_app/core/theme/app_colors.dart';
import 'package:lmd_app/core/theme/app_text.dart';

class FAQItem {
  final String question;
  final String answer;

  const FAQItem({
    required this.question,
    required this.answer,
  });
}

class HelpCenterPage extends StatefulWidget {
  const HelpCenterPage({super.key});

  @override
  State<HelpCenterPage> createState() => _HelpCenterPageState();
}

class _HelpCenterPageState extends State<HelpCenterPage> {
  final List<FAQItem> _faqs = const [
    FAQItem(
      question: 'How do I book a hotel?',
      answer: "Search for your destination or category on our home page, select your preferred hotel deal, choose your dates, and click 'Book Now'. Follow the checkout instructions to complete your payment.",
    ),
    FAQItem(
      question: 'When will I receive my booking confirmation?',
      answer: "Your booking voucher and confirmation email are generated instantly upon successful payment. You can also view all your active bookings anytime under 'My Trip' in your profile.",
    ),
    FAQItem(
      question: 'Can I cancel my booking?',
      answer: 'Cancellation policies vary by hotel and deal type. Please review the specific cancellation rules listed on the hotel detail page before confirming your reservation.',
    ),
    FAQItem(
      question: 'Can I modify my booking?',
      answer: "To modify dates or guest details, please contact our support team directly. Modifications are subject to availability and the specific hotel's policy.",
    ),
    FAQItem(
      question: 'Is my payment secure?',
      answer: 'Yes, all transactions are processed through secure, encrypted payment gateways. We do not store your complete card details on our servers.',
    ),
    FAQItem(
      question: "I didn't receive my booking confirmation.",
      answer: "Please check your spam or promotions folder first. If it's still missing, log in to your account to view your booking under 'My Trip', or contact support.",
    ),
  ];

  List<FAQItem> _filteredFaqs = [];
  String _searchQuery = '';
  final Set<int> _expandedIndices = {};

  @override
  void initState() {
    super.initState();
    _filteredFaqs = _faqs;
  }

  void _onSearchChanged(String query) {
    setState(() {
      _searchQuery = query;
      _expandedIndices.clear(); // Close any open answers during search
      if (query.trim().isEmpty) {
        _filteredFaqs = _faqs;
      } else {
        _filteredFaqs = _faqs
            .where((faq) =>
                faq.question.toLowerCase().contains(query.toLowerCase()) ||
                faq.answer.toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Back Button Row
              GestureDetector(
                onTap: () => Navigator.pop(context),
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0.h),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.arrow_back,
                        color: AppColors.textSecondary,
                        size: 20.r,
                      ),
                      SizedBox(width: 8.w),
                      Text(
                        'Help Center',
                        style: AppText.bodyMedium.copyWith(
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 24.h),

              // Search Bar
              Center(
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 600),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12.r),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: TextField(
                    onChanged: _onSearchChanged,
                    decoration: InputDecoration(
                      hintText: 'Search for help...',
                      hintStyle: TextStyle(color: Colors.grey[400], fontSize: 15.sp),
                      prefixIcon: const Icon(Icons.search, color: AppColors.textSecondary),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 14.h, horizontal: 16.w),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 32.h),

              // "Frequently Asked Questions" title
              Center(
                child: Container(
                  width: double.infinity,
                  constraints: const BoxConstraints(maxWidth: 600),
                  child: Text(
                    'Frequently Asked Questions',
                    style: AppText.h2.copyWith(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 16.h),

              // FAQs List
              Center(
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 600),
                  child: _filteredFaqs.isEmpty
                      ? Padding(
                          padding: EdgeInsets.symmetric(vertical: 32.0.h),
                          child: Center(
                            child: Text(
                              'No results found for "$_searchQuery"',
                              style: AppText.bodySecondary.copyWith(
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ),
                        )
                      : ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _filteredFaqs.length,
                          separatorBuilder: (context, index) => SizedBox(height: 16.h),
                          itemBuilder: (context, index) {
                            final faq = _filteredFaqs[index];
                            final originalIndex = _faqs.indexOf(faq);
                            final isExpanded = _expandedIndices.contains(originalIndex);

                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              curve: Curves.easeInOut,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16.r),
                                border: Border.all(color: AppColors.border),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        if (isExpanded) {
                                          _expandedIndices.remove(originalIndex);
                                        } else {
                                          _expandedIndices.add(originalIndex);
                                        }
                                      });
                                    },
                                    borderRadius: BorderRadius.circular(16.r),
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 18.h),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              faq.question,
                                              style: TextStyle(
                                                fontSize: 15.sp,
                                                fontWeight: FontWeight.w600,
                                                color: AppColors.textPrimary,
                                              ),
                                            ),
                                          ),
                                          SizedBox(width: 8.w),
                                          Icon(
                                            isExpanded
                                                ? Icons.keyboard_arrow_up
                                                : Icons.keyboard_arrow_down,
                                            color: AppColors.primary,
                                            size: 22.r,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  if (isExpanded) ...[
                                    const Divider(color: AppColors.border, height: 1),
                                    Padding(
                                      padding: EdgeInsets.all(20.w),
                                      child: Text(
                                        faq.answer,
                                        style: TextStyle(
                                          fontSize: 14.sp,
                                          color: Colors.grey[600],
                                          height: 1.5,
                                        ),
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            );
                          },
                        ),
                ),
              ),
              SizedBox(height: 32.h),

              // Bottom Support Card
              Center(
                child: Container(
                  width: double.infinity,
                  constraints: const BoxConstraints(maxWidth: 600),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFE4E4),
                    borderRadius: BorderRadius.circular(24.r),
                  ),
                  padding: EdgeInsets.all(32.w),
                  child: Column(
                    children: [
                      // Red icon badge
                      Container(
                        width: 56.w,
                        height: 56.h,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(16.r),
                        ),
                        child: Icon(
                          Icons.help_outline_rounded,
                          color: Colors.white,
                          size: 28.r,
                        ),
                      ),
                      SizedBox(height: 20.h),

                      // "Still need help?" title
                      Text(
                        'Still need help?',
                        style: AppText.h2.copyWith(
                          color: AppColors.textPrimary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 12.h),

                      // Subtitle description
                      Text(
                        'Our 24/7 support team is here to assist you with any questions or concerns.',
                        textAlign: TextAlign.center,
                        style: AppText.bodySecondary.copyWith(
                          color: AppColors.textSecondary,
                          fontSize: 14.sp,
                          height: 1.5,
                        ),
                      ),
                      SizedBox(height: 24.h),

                      // CONTACT SUPPORT Button
                      SizedBox(
                        height: 48.h,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r),
                            ),
                            padding: EdgeInsets.symmetric(horizontal: 24.w),
                          ),
                          onPressed: () {
                            // Returns back to the Contact Us screen
                            Navigator.pop(context);
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'CONTACT SUPPORT',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14.sp,
                                ),
                              ),
                              SizedBox(width: 8.w),
                              Icon(
                                Icons.arrow_forward_rounded,
                                color: Colors.white,
                                size: 16.r,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
