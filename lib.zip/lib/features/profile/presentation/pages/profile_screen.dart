import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:intl/intl.dart';
import 'package:lmd_app/features/booking/presentation/cubit/booking_history_cubit.dart';
import 'package:lmd_app/core/theme/app_colors.dart';
import 'package:lmd_app/features/auth/presentation/cubit/auth_cubit.dart';
import 'package:lmd_app/features/auth/presentation/cubit/auth_state.dart';
import 'package:lmd_app/core/widgets/user_avatar.dart';
import 'package:lmd_app/core/constants/app_images.dart';
import 'package:lmd_app/features/auth/presentation/pages/login_page.dart';
import 'package:lmd_app/features/wishlist/presentation/pages/wishlist_page.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:lmd_app/features/notifications/presentation/pages/notifications_page.dart';
import 'package:lmd_app/features/profile/presentation/pages/customer_support_page.dart';
import 'package:lmd_app/features/profile/presentation/pages/edit_profile_page.dart';
import 'package:lmd_app/features/booking/data/services/booking_service.dart';
import 'package:lmd_app/features/booking/presentation/pages/bookings_history_page.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Neutral palette used across the redesigned Profile UI
  static const Color _textPrimary = Color(0xFF111827);
  static const Color _textSecondary = Color(0xFF374151);
  static const Color _textTertiary = Color(0xFF6B7280);
  static const Color _borderNeutral = Color(0xFFE5E7EB);
  static const Color _bgSubtle = Color(0xFFF3F4F6);
  static const Color _dividerNeutral = Color(0xFFF9FAFB);
  static const Color _chevronNeutral = Color(0xFF9CA3AF);

  int? _bookingsCount;

  @override
  void initState() {
    super.initState();
    // Load fresh user profile details from API
    context.read<AuthCubit>().loadProfile();
    _fetchBookingsCount();
  }

  Future<void> _fetchBookingsCount() async {
    final authState = context.read<AuthCubit>().state;
    if (authState.user == null) {
      return;
    }
    try {
      final bookings = await BookingService().getMyBookings(status: '');
      if (mounted) {
        setState(() {
          _bookingsCount = bookings.length;
        });
      }
    } catch (e) {
      debugPrint('Error fetching bookings count: $e');
    }
  }

  String _formatDob(String dob) {
    try {
      final date = DateTime.parse(dob);
      return DateFormat('MMMM d, yyyy').format(date);
    } catch (_) {
      return dob;
    }
  }



  Future<void> openInstagram() async {
    final Uri url = Uri.parse(
      'https://www.instagram.com/nearby.hoteldeals?igsh=N2Nkdm5rbG84NmFs&utm_source=qr',
    );

    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch Instagram');
    }
  }

  Future<void> openFacebook() async {
    final Uri url = Uri.parse(
      'https://www.facebook.com/people/Last-Minutes-Deal/61569357812156/?rdid=hRFzs3KCl7EqpkkM&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1K7VtbuRxN%2F',
    );

    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch Facebook');
    }
  }

  Future<void> openLinkedin() async {
    final Uri url = Uri.parse(
      'https://www.linkedin.com/company/nearby-hotel-deals-by-last-minutes-deal/posts/?feedView=all',
    );

    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch Linkedin');
    }
  }

  Future<void> openX() async {
    final Uri url = Uri.parse('https://x.com/LastMinutesDeal');
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch X/Twitter');
    }
  }

  Future<void> openHosting() async {
    final Uri url = Uri.parse('https://admin.lastminutessdeal.com/login');
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch Hosting');
    }
  }



  @override
  Widget build(BuildContext context) {
    Future<bool> showLogoutConfirmationDialog() async {
      return await showDialog<bool>(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('confirm_logout'.tr()),
              content:  Text('are_you_sure_logout'.tr()),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: Text(
                    'no'.tr(),
                    style: TextStyle(color: Colors.black),
                  ),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context, true),
                  style: ElevatedButton.styleFrom(),
                  child: Text(
                    'yes'.tr(),
                    style: TextStyle(color: AppColors.primary),
                  ),
                ),
              ],
            ),
          ) ??
          false; // Return false if dialog is dismissed without selection
    }

    final mediaQuery = MediaQuery.of(context);
    final topPadding = mediaQuery.padding.top;
    final bottomPadding = mediaQuery.padding.bottom;
    final screenWidth = mediaQuery.size.width;

    return BlocBuilder<AuthCubit, AuthState>(
      builder: (context, state) {
        final user = state.user;
        return Scaffold(
          backgroundColor: AppColors.background,
          body: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 600),
              child: RefreshIndicator(
                color: AppColors.active,
                onRefresh: () async {
                  await context.read<AuthCubit>().loadProfile();
                  await _fetchBookingsCount();
                },
                child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.only(bottom: bottomPadding + 84),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 1. Top Profile Header Section - clean white header
                    Container(
                      width: double.infinity,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        border: Border(
                          bottom: BorderSide(color: Color(0xFFF3F4F6), width: 1),
                        ),
                      ),
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(20, topPadding + 48, 20, 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${user?.firstName ?? "there".tr()} ${user?.lastName ?? ''}'.trim(),
                                    style: TextStyle(
                                      color: _textPrimary,
                                      fontSize: 20.sp,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: -0.3,
                                    ),
                                  ),
                                  SizedBox(height: 4.h),
                                  Text(
                                    user?.email ?? 'Log in to manage your account',
                                    style: TextStyle(
                                      color: _textTertiary,
                                      fontSize: 13.sp,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(width: 16.w),
                            Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _bgSubtle,
                                border: Border.all(
                                  color: _borderNeutral,
                                  width: 1,
                                ),
                              ),
                              child: UserAvatar(
                                imageUrl: user?.profileImage,
                                name: user?.firstName ?? '',
                                radius: 28,
                                size: 26.r,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: screenWidth > 600 ? 24.0 : 16.0),
                      child: Column(
                        children: [
                          SizedBox(height: 4.h),

                          // 2. Row of 3 Actions: My Trips, Profile, Wishlists
                          Row(
                            children: [
                              Expanded(
                                child: _buildQuickActionButton(
                                  icon: Icons.assignment_outlined,
                                  label: 'my_trips'.tr(),
                                  badgeText: _bookingsCount != null && _bookingsCount! > 0
                                      ? _bookingsCount.toString()
                                      : null,
                                  onTap: () {
                                    if (user == null) {
                                      Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(builder: (_) => const LoginPage()),
                                      );
                                    } else {
                                      Navigator.push(
  context,
  MaterialPageRoute(
    builder: (_) => BlocProvider<BookingHistoryCubit>(
      create: (_) => BookingHistoryCubit(
        bookingService: BookingService(),
      )..loadBookingHistory(),
      child: const BookingsHistoryPage(),
    ),
  ),
);
                                    }
                                  },
                                ),
                              ),
                              SizedBox(width: 12.w),
                              Expanded(
                                child: _buildQuickActionButton(
                                  icon: Icons.person_outline_rounded,
                                  label: 'profile'.tr(),
                                  onTap: () {
                                    if (user == null) {
                                      Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(builder: (_) => const LoginPage()),
                                      );
                                    } else {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => const EditProfilePage(),
                                        ),
                                      ).then((_) {
                                        if (context.mounted) {
                                          context.read<AuthCubit>().loadProfile();
                                        }
                                      });
                                    }
                                  },
                                ),
                              ),
                              SizedBox(width: 12.w),
                              Expanded(
                                child: _buildQuickActionButton(
                                  icon: Icons.favorite_border_rounded,
                                  label: 'wishlists'.tr(),
                                  onTap: () {
                                    Navigator.push(context, MaterialPageRoute(builder: (context) =>WishlistPage()));
                                    // ScaffoldMessenger.of(context).showSnackBar(
                                    //   const SnackBar(content: Text('Wishlist feature is coming soon!')),
                                    //
                                    // );
                                  },
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 16.h),

                          // 3. Complete Your Profile Banner Card (replaces Birthday Surprise)
                          Container(
                            width: double.infinity,
                            padding: EdgeInsets.all(16.w),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12.r),
                              border: Border.all(color: _borderNeutral, width: 1),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'complete_your_profile'.tr(),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: _textPrimary,
                                          fontSize: 14.sp,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      SizedBox(height: 4.h),
                                      if (user?.dob == null || user!.dob!.isEmpty)
                                        Text(
                                          'add_birthday_for_perks'.tr(),
                                          style: TextStyle(
                                            color: _textTertiary,
                                            fontSize: 12.sp,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        )
                                      else
                                        Text(
                                          _formatDob(user.dob!),
                                          style: TextStyle(
                                            color: _textTertiary,
                                            fontSize: 12.sp,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                if (user?.dob == null || user!.dob!.isEmpty)
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => const EditProfilePage(),
                                        ),
                                      ).then((_) {
                                        if (context.mounted) {
                                          context.read<AuthCubit>().loadProfile();
                                        }
                                      });
                                    },
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(vertical: 4.h),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            'add'.tr(),
                                            style: TextStyle(
                                              color: _textPrimary,
                                              fontSize: 13.sp,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          Icon(
                                            Icons.chevron_right,
                                            color: _textPrimary,
                                            size: 16.r,
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                else
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => const EditProfilePage(),
                                        ),
                                      ).then((_) {
                                        if (context.mounted) {
                                          context.read<AuthCubit>().loadProfile();
                                        }
                                      });
                                    },
                                    child: Icon(
                                      Icons.edit_rounded,
                                      color: _chevronNeutral,
                                      size: 18.r,
                                    ),
                                  ),
                              ],
                            ),
                          ),

                          SizedBox(height: 12.h),

                          // 4. Main Menu Items Card
                          Container(
                            decoration: _buildCardDecoration(),
                            child: Column(
                              children: [
                                _buildListTile(
                                  icon: Icons.chat_bubble_outline_rounded,
                                  title: 'customer_support'.tr(),
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => const CustomerSupportPage(),
                                      ),
                                    );
                                  },
                                ),
                                _buildDivider(),
                                _buildListTile(
                                  icon: Icons.notifications_none_rounded,
                                  title: 'notifications'.tr(),
                                  onTap: () => NotificationsPage.open(context),
                                ),
                                _buildDivider(),
                                _buildListTile(
                                  icon: Icons.rate_review_outlined,
                                  title: 'my_reviews'.tr(),
                                  onTap: () {},
                                ),
                                _buildDivider(),
                                _buildListTile(
                                  icon: Icons.card_giftcard_rounded,
                                  title: 'gift_cards'.tr(),
                                  onTap: () {},
                                ),
                                _buildDivider(),
                                _buildListTile(
                                  icon: Icons.people_outline_rounded,
                                  title: 'refer_and_earn'.tr(),
                                  onTap: () {},
                                ),
                              ],
                            ),
                          ),

                          SizedBox(height: 12.h),

                          // 5. Get Started with Hosting Card
                          Container(
                            decoration: _buildCardDecoration(),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap: openHosting,
                                borderRadius: BorderRadius.circular(12.r),
                                child: Padding(
                                  padding: EdgeInsets.all(12.w),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 56.w,
                                        height: 56.h,
                                        decoration: BoxDecoration(
                                          color: _bgSubtle,
                                          borderRadius: BorderRadius.circular(8.r),
                                        ),
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(8.r),
                                          child: Image.asset(
                                            'assets/images/limitedOffer.png',
                                            width: 56.w,
                                            height: 56.h,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 14.w),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'get_started_with_hosting'.tr(),
                                              style: TextStyle(
                                                color: _textPrimary,
                                                fontSize: 14.sp,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            const SizedBox(height: 3),
                                            Text(
                                              'limited_offer_earn_more'.tr(),
                                              style: TextStyle(
                                                color: _textTertiary,
                                                fontSize: 12.sp,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Icon(
                                        Icons.chevron_right,
                                        color: _chevronNeutral,
                                        size: 16.r,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),

                          SizedBox(height: 12.h),

                          // 6. Settings Card (Grouped under "Settings" header inside the card)
                          Container(
                            decoration: _buildCardDecoration(),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsets.fromLTRB(16.w, 16.h, 16.w, 8.h),
                                  child: Text(
                                    'settings'.tr(),
                                    style: TextStyle(
                                      color: _textTertiary,
                                      fontSize: 13.sp,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.4,
                                    ),
                                  ),
                                ),
                                _buildListTile(
                                  icon: Icons.account_balance_outlined,
                                  title: 'country'.tr(),
                                  onTap: () {},
                                ),
                                _buildDivider(),
                                _buildListTile(
                                  icon: Icons.payments_outlined,
                                  title: 'currency'.tr(),
                                  onTap: () {},
                                ),
                                _buildDivider(),
                                _buildListTile(
                                  icon: Icons.notifications_active_outlined,
                                  title: 'communication_preferences'.tr(),
                                  onTap: () {},
                                ),
                              ],
                            ),
                          ),

                          SizedBox(height: 12.h),

                          // 7. Rate Us Card
                          Container(
                            decoration: _buildCardDecoration(),
                            child: _buildListTile(
                              icon: Icons.star_outline_rounded,
                              title: 'rate_us'.tr(),
                              onTap: () {},
                            ),
                          ),

                          SizedBox(height: 12.h),

                          // 8. Log Out Card (Red border/theme)
                          if (user == null)
                            Container(
                              height: 52.h,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12.r),
                                border: Border.all(
                                  color: _borderNeutral,
                                  width: 1,
                                ),
                              ),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => const LoginPage(),
                                      ),
                                    );
                                  },
                                  borderRadius: BorderRadius.circular(12.r),
                                  child: Padding(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 16.0.w,
                                    ),
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.login_rounded,
                                          color: _textTertiary,
                                          size: 20.r,
                                        ),
                                        SizedBox(width: 14.w),
                                        Expanded(
                                          child: Text(
                                            'log_in_register'.tr(),
                                            style: TextStyle(
                                              color: _textPrimary,
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                        Icon(
                                          Icons.chevron_right,
                                          color: _chevronNeutral,
                                          size: 16.r,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            )
                          else
                            Container(
                              height: 52.h,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12.r),
                                border: Border.all(
                                  color: _borderNeutral,
                                  width: 1,
                                ),
                              ),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: () async {
                                    if (await showLogoutConfirmationDialog()) {
                                      if (!context.mounted) return;
                                      await context.read<AuthCubit>().logout();

                                      if (context.mounted) {
                                        Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => const LoginPage(),
                                          ),
                                        );
                                      }
                                    }
                                  },
                                  borderRadius: BorderRadius.circular(12.r),
                                  child: Padding(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 16.0.w,
                                    ),
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.logout_rounded,
                                          color: _textTertiary,
                                          size: 20.r,
                                        ),
                                        SizedBox(width: 14.w),
                                        Expanded(
                                          child: Text(
                                            'log_out'.tr(),
                                            style: TextStyle(
                                              color: _textPrimary,
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                        Icon(
                                          Icons.chevron_right,
                                          color: _chevronNeutral,
                                          size: 16.r,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                          SizedBox(height: 28.h),

                          // 9. Footer Text & Social Links
                          Text(
                            'join_with_us_show_some_love'.tr(),
                            style: TextStyle(
                              color: _textTertiary,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(height: 16.h),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _buildSocialImageButton(
                                AppImages.facebookIcon,
                                onTap: () {
                                  openFacebook();
                                },
                              ),
                              SizedBox(width: 16.w),
                              _buildSocialImageButton(
                                AppImages.instaIcon,
                                onTap: () {
                                  openInstagram();
                                },
                              ),
                              SizedBox(width: 16.w),
                              _buildSocialImageButton(
                                'assets/profile_page/twitterXIcon.png',
                                onTap: () {
                                  openX();
                                },
                              ),
                              SizedBox(width: 16.w),
                              _buildSocialImageButton(
                                AppImages.linkedinIcon,
                                onTap: () {
                                  openLinkedin();
                                },
                              ),
                            ],
                          ),
                          SizedBox(height: 36.h),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              ),
            ),
          ),
        );
      },
    );
  }

  // Helper widget to build the Action row options (My Trips, Profile, Wishlists)
  Widget _buildQuickActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    String? badgeText,
  }) {
    return Container(
      height: 80.h,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: _borderNeutral, width: 1.0),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12.r),
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 14.0.h),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Icon(icon, color: _textPrimary, size: 22.r),
                    if (badgeText != null)
                      Positioned(
                        top: -6,
                        right: -10,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
                          decoration: BoxDecoration(
                            color: _textPrimary,
                            borderRadius: BorderRadius.circular(10.r),
                          ),
                          constraints: const BoxConstraints(
                            minWidth: 16,
                            minHeight: 16,
                          ),
                          child: Text(
                            badgeText,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 8.sp,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                  ],
                ),
                SizedBox(height: 8.h),
                Text(
                  label,
                  style: TextStyle(
                    color: _textSecondary,
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Common BoxDecoration helper for white cards
  BoxDecoration _buildCardDecoration() {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12.r),
      border: Border.all(color: _borderNeutral, width: 1.0),
    );
  }

  // Helper widget to build list tile row items inside containers
  Widget _buildListTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12.r),
        child: Container(
          height: 52.h,
          padding: EdgeInsets.symmetric(horizontal: 16.0.w),
          child: Row(
            children: [
              Icon(icon, color: _textPrimary, size: 20.r),
              SizedBox(width: 14.w),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: _chevronNeutral,
                size: 16.r,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Helper to draw divider lines
  Widget _buildDivider() {
    return const Divider(
      height: 1,
      thickness: 1,
      indent: 16,
      endIndent: 16,
      color: _dividerNeutral,
    );
  }

  // Helper to build social media logo image buttons
  Widget _buildSocialImageButton(
    String assetPath, {
    required VoidCallback onTap,
  }) {
    // If twitterXIcon.svg is passed, use the valid twitterXIcon.png asset
    String resolvedPath = assetPath;
    if (resolvedPath == AppImages.twitterIcon ||
        resolvedPath.contains('twitterXIcon.svg')) {
      resolvedPath = 'assets/profile_page/twitterXIcon.png';
    }

    final bool isSvg = resolvedPath.toLowerCase().endsWith('.svg');

    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8.r),
        child: SizedBox(
          width: 32.w,
          height: 32.h,
          child: isSvg
              ? SvgPicture.asset(
                  resolvedPath,
                  width: 32.w,
                  height: 32.h,
                  fit: BoxFit.cover,
                )
              : Image.asset(
                  resolvedPath,
                  width: 32.w,
                  height: 32.h,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      SizedBox(width: 32.w, height: 32.h),
                ),
        ),
      ),
    );
  }
}