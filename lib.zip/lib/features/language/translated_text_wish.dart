import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:lmd_app/core/services/translation_service.dart';

class TranslatedText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final int? maxLines;
  final TextOverflow? overflow;
  final TextAlign? textAlign;

  const TranslatedText({
    super.key,
    required this.text,
    this.style,
    this.maxLines,
    this.overflow,
    this.textAlign,
  });

  @override
  Widget build(BuildContext context) {
    final currentLang = context.locale.languageCode;

    // Fast path for English: render directly without async overhead
    if (currentLang == 'en') {
      return Text(
        text,
        style: style,
        maxLines: maxLines,
        overflow: overflow,
      );
    }

    return FutureBuilder<String>(
      future: TranslationService().translate(text, currentLang),
      builder: (context, snapshot) {
        final displayText = snapshot.data ?? text; // Show English while loading
        return Text(
          displayText,
          style: style,
          maxLines: maxLines,
          overflow: overflow,
        );
      },
    );
  }
}