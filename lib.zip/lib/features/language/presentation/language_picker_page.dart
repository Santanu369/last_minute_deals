import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:lmd_app/core/services/lanrepos.dart';
import 'package:lmd_app/features/language/model/lan_model.dart';

class LanguagePicker extends StatefulWidget {
  const LanguagePicker({super.key});

  @override
  State<LanguagePicker> createState() => _LanguagePickerState();
}

class _LanguagePickerState extends State<LanguagePicker> {
  final TextEditingController searchController = TextEditingController();

  final LanguageRepository repository = LanguageRepository();

  List<LanguageModel> languages = [];
  List<LanguageModel> filteredLanguages = [];

  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadLanguages();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _loadLanguages() async {
    try {
      final result = await repository.getLanguages();

      if (!mounted) return;
      setState(() {
        languages = result;
        filteredLanguages = result;
        loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
      });
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('language_load_error'.tr())));
    }
  }

  void _search(String value) {
    final query = value.toLowerCase();

    setState(() {
      filteredLanguages = languages.where((language) {
        return language.name.toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final selectedLanguage = context.locale.languageCode;

    return SafeArea(
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.8,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'select_language'.tr(),
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: searchController,
                onChanged: _search,
                decoration: InputDecoration(
                  hintText: 'search'.tr(),
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 10),

            Expanded(
              child: loading
                  ? const Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      itemCount: filteredLanguages.length,
                      itemBuilder: (context, index) {
                        final language = filteredLanguages[index];

                        final isSelected = language.code == selectedLanguage;

                        return ListTile(
                          title: Text(language.nativeName),
                          subtitle: Text(language.name),
                          trailing: isSelected ? const Icon(Icons.check) : null,
                          onTap: () async {
                            final locale = Locale(language.code);

                            await context.setLocale(locale);
                            if (!context.mounted) return;
                            Navigator.of(context).pop();
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
